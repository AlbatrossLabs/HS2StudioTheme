using System.Collections.Generic;
using System.Linq;
using System.Text;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace HS2StudioTheme
{
    /// <summary>
    /// iPhone-style folders for the tool buttons at the bottom left (Studio's and every plugin's).
    /// Drag a button onto another to put both in a folder; drag more onto the folder to add them;
    /// click the folder to open it; drag a button out of an open folder to take it back out. Dragging
    /// a button or folder to an empty spot moves it there. The buttons fill the toolbar's own grid
    /// from its first cell, so taking buttons into folders closes up the gaps. Layout is saved in F1
    /// › Toolbar folders; turning the theme off puts every button back where Studio / KKAPI had it.
    /// </summary>
    internal class ToolbarFolders : MonoBehaviour
    {
        private class Folder
        {
            public string Id, Name;
            public readonly List<string> Members = new List<string>();
            public RectTransform Rt;
            public Image Glass;
            public readonly List<Image> Minis = new List<Image>();
        }

        private const float Cell = 40f, PanelPad = 8f, TitleH = 24f;
        private const int PanelColumns = 4;

        private readonly Dictionary<string, RectTransform> _buttons = new Dictionary<string, RectTransform>();
        private readonly Dictionary<RectTransform, Vector2> _natural = new Dictionary<RectTransform, Vector2>();
        private readonly Dictionary<RectTransform, Vector2> _assigned = new Dictionary<RectTransform, Vector2>();
        private readonly List<string> _order = new List<string>();
        private readonly Dictionary<string, Folder> _folders = new Dictionary<string, Folder>();
        private Vector2 _size = new Vector2(32f, 32f);
        private RectTransform _rt, _panel;
        private InputField _title;
        private Folder _open;
        private RectTransform _dragging, _hoverTarget;
        private Vector2 _grab;
        private float _next;
        private bool _removed, _layoutDirty = true;

        public static ToolbarFolders Attach(Transform group, Undo undo)
        {
            if (group == null || group.GetComponent<ToolbarFolders>() != null) return null;
            var f = group.gameObject.AddComponent<ToolbarFolders>();
            f._rt = (RectTransform)group;
            undo.Add(f.Remove);
            f.Load();
            f.Scan();
            return f;
        }

        // ------------------------------------------------------------------ model

        private void Load()
        {
            _order.Clear();
            _folders.Clear();
            var text = StudioThemePlugin.ToolbarLayout.Value ?? "";
            foreach (var part in text.Split(';'))
            {
                if (part.StartsWith("order="))
                    _order.AddRange(part.Substring(6).Split('|').Where(s => s.Length > 0));
                else if (part.StartsWith("folder:"))
                {
                    int eq = part.IndexOf('=');
                    if (eq < 0) continue;
                    var head = part.Substring(7, eq - 7).Split('~');
                    var f = new Folder { Id = head[0], Name = head.Length > 1 ? head[1] : "Folder" };
                    f.Members.AddRange(part.Substring(eq + 1).Split('|').Where(s => s.Length > 0));
                    if (f.Members.Count > 0) _folders[f.Id] = f;
                }
            }
        }

        private void Save()
        {
            var sb = new StringBuilder("order=").Append(string.Join("|", _order.ToArray()));
            foreach (var f in _folders.Values)
                sb.Append(";folder:").Append(f.Id).Append('~').Append(f.Name.Replace(";", "").Replace("|", "").Replace("=", "").Replace("~", ""))
                  .Append('=').Append(string.Join("|", f.Members.ToArray()));
            StudioThemePlugin.ToolbarLayout.Value = sb.ToString();
        }

        private static bool IsFolderKey(string key) { return key.StartsWith("@"); }

        private Folder FolderOf(string key)
        {
            foreach (var f in _folders.Values) if (f.Members.Contains(key)) return f;
            return null;
        }

        // ------------------------------------------------------------------ buttons

        /// <summary>Pick up buttons as they appear (plugins add theirs late) and notice KKAPI re-placing them.</summary>
        private void Scan()
        {
            for (int i = 0; i < _rt.childCount; i++)
            {
                var t = _rt.GetChild(i) as RectTransform;
                if (t == null || t.name.StartsWith(ThemedButton.OwnPrefix) || t.GetComponent<Button>() == null) continue;
                if (!_buttons.ContainsKey(t.name))
                {
                    _buttons[t.name] = t;
                    _natural[t] = t.anchoredPosition;
                    _size = t.sizeDelta;
                    t.gameObject.AddComponent<ToolbarDrag>().Owner = this;
                    _layoutDirty = true;
                }
                else if (_buttons[t.name] != t) { _buttons[t.name] = t; _natural[t] = t.anchoredPosition; _layoutDirty = true; }
            }
            // Someone else (KKAPI's layout) moved a button: that's its new home cell.
            foreach (var t in _buttons.Values)
            {
                Vector2 a;
                if (t == null || t == _dragging) continue;
                if (_assigned.TryGetValue(t, out a) && (t.anchoredPosition - a).sqrMagnitude > 0.5f)
                {
                    _natural[t] = t.anchoredPosition;
                    _layoutDirty = true;
                }
            }
        }

        private bool Visible(string key)
        {
            RectTransform t;
            return _buttons.TryGetValue(key, out t) && t != null && t.gameObject.activeSelf;
        }

        /// <summary>Studio swaps "Axis" and "Target" in the same spot: treat them as one slot.</summary>
        private RectTransform Resolve(string key)
        {
            RectTransform t;
            if (key == "Button Axis" && !Visible(key) && Visible("Button Target")) key = "Button Target";
            return _buttons.TryGetValue(key, out t) && t != null && t.gameObject.activeSelf ? t : null;
        }

        // ------------------------------------------------------------------ layout

        private void LateUpdate()
        {
            if (_removed) return;
            if (Time.unscaledTime >= _next)
            {
                _next = Time.unscaledTime + 0.5f;
                Scan();
            }
            if (_dragging == null && (_layoutDirty || Time.frameCount % 30 == 0)) Layout();
            if (_open != null && Input.GetMouseButtonDown(0) && !PointerOver(_panel) && !PointerOver(_open.Rt) && _dragging == null) Close();
            if (_open != null && Input.GetKeyDown(KeyCode.Escape)) Close();
        }

        /// <summary>The grid's cells: every place a visible button was put by Studio / KKAPI, nearest the first cell first.</summary>
        private List<Vector2> Cells()
        {
            var cells = new List<Vector2>();
            foreach (var kv in _natural)
                if (kv.Key != null && kv.Key.gameObject.activeSelf && !cells.Any(c => (c - kv.Value).sqrMagnitude < 4f)) cells.Add(kv.Value);
            if (cells.Count == 0) return cells;
            float ox = cells.Min(c => c.x), oy = cells.Min(c => c.y);
            cells.Sort((a, b) =>
            {
                int ra = Mathf.RoundToInt((a.x - ox) / Cell) + Mathf.RoundToInt((a.y - oy) / Cell);
                int rb = Mathf.RoundToInt((b.x - ox) / Cell) + Mathf.RoundToInt((b.y - oy) / Cell);
                if (ra != rb) return ra.CompareTo(rb);
                if (Mathf.Abs(a.x - b.x) > 1f) return a.x.CompareTo(b.x);
                return a.y.CompareTo(b.y);
            });
            return cells;
        }

        /// <summary>Top-level entries in order: the saved order, then any new buttons in their natural order.</summary>
        private List<string> TopLevel(List<Vector2> cells)
        {
            var top = new List<string>();
            foreach (var key in _order)
            {
                if (IsFolderKey(key)) { if (_folders.ContainsKey(key.Substring(1)) && FolderVisible(_folders[key.Substring(1)])) top.Add(key); }
                else if (FolderOf(key) == null && Resolve(key) != null && !top.Contains(key)) top.Add(key);
            }
            var rest = _buttons.Keys.Where(k => !_order.Contains(k) && FolderOf(k) == null && Resolve(k) != null && !(k == "Button Target" && _order.Contains("Button Axis")))
                .OrderBy(k => Rank(_natural[_buttons[k]], cells)).ToList();
            top.AddRange(rest);
            foreach (var f in _folders.Values) if (!top.Contains("@" + f.Id) && FolderVisible(f)) top.Add("@" + f.Id);
            return top;
        }

        private bool FolderVisible(Folder f) { return f.Members.Any(m => Resolve(m) != null); }

        private static int Rank(Vector2 p, List<Vector2> cells)
        {
            for (int i = 0; i < cells.Count; i++) if ((cells[i] - p).sqrMagnitude < 4f) return i;
            return cells.Count;
        }

        private void Layout()
        {
            _layoutDirty = false;
            var cells = Cells();
            if (cells.Count == 0) return;
            var top = TopLevel(cells);
            // More entries than cells (shouldn't happen): extend upwards in the first column.
            while (cells.Count < top.Count) cells.Add(cells[cells.Count - 1] + new Vector2(0f, Cell));

            for (int i = 0; i < top.Count; i++)
            {
                var key = top[i];
                if (IsFolderKey(key))
                {
                    var f = _folders[key.Substring(1)];
                    EnsureFolderView(f);
                    f.Rt.anchoredPosition = cells[i];
                    f.Rt.sizeDelta = _size;
                    f.Rt.gameObject.SetActive(true);
                }
                else Put(Resolve(key), cells[i], true);
            }
            foreach (var f in _folders.Values)
            {
                if (f.Rt != null && !top.Contains("@" + f.Id)) f.Rt.gameObject.SetActive(false);
                if (f == _open) continue;
                foreach (var m in f.Members) { var t = Resolve(m); if (t != null) Hide(t); }
            }
            if (_open != null) LayoutPanel();
        }

        private void Put(RectTransform t, Vector2 pos, bool shown)
        {
            if (t == null) return;
            t.anchoredPosition = pos;
            _assigned[t] = pos;
            if (shown && t.localScale != Vector3.one) t.localScale = Vector3.one;
        }

        /// <summary>A button inside a closed folder: shrunk to nothing (no picture, no clicks), left where it is.</summary>
        private void Hide(RectTransform t)
        {
            if (t.localScale != Vector3.zero) t.localScale = Vector3.zero;
            _assigned[t] = t.anchoredPosition;
        }

        // ------------------------------------------------------------------ folder view

        private void EnsureFolderView(Folder f)
        {
            if (f.Rt == null)
            {
                var go = new GameObject(ThemedButton.OwnPrefix + "Folder " + f.Id, typeof(RectTransform));
                go.layer = gameObject.layer;
                go.transform.SetParent(_rt, false);
                f.Rt = (RectTransform)go.transform;
                f.Rt.anchorMin = f.Rt.anchorMax = new Vector2(0f, 1f);
                f.Rt.pivot = new Vector2(0f, 1f);
                f.Glass = go.AddComponent<Image>();
                f.Glass.sprite = Sprites.Panel;
                f.Glass.type = Image.Type.Sliced;
                var button = go.AddComponent<Button>();
                button.transition = Selectable.Transition.ColorTint;
                var cb = button.colors; cb.highlightedColor = new Color(1.15f, 1.15f, 1.15f, 1f); cb.pressedColor = new Color(0.8f, 0.8f, 0.8f, 1f); button.colors = cb;
                var folder = f;
                button.onClick.AddListener(() => { if (_open == folder) Close(); else Open(folder); });
                go.AddComponent<ToolbarDrag>().Owner = this;
                var tip = go.AddComponent<FolderTip>();
                tip.Text = () => folder.Name + "  ·  " + string.Join(", ", folder.Members.Select(Pretty).ToArray());
            }
            // 2 x 2 miniatures of the first four members' icons.
            foreach (var m in f.Minis) if (m != null) Destroy(m.gameObject);
            f.Minis.Clear();
            int n = 0;
            foreach (var key in f.Members)
            {
                if (n >= 4) break;
                var t = Resolve(key);
                if (t == null) continue;
                var src = IconOf(t);
                if (src == null) continue;
                var go = new GameObject(ThemedButton.OwnPrefix + "Mini", typeof(RectTransform));
                go.transform.SetParent(f.Rt, false);
                var rt = (RectTransform)go.transform;
                rt.anchorMin = rt.anchorMax = new Vector2(0.5f, 0.5f);
                rt.sizeDelta = new Vector2(11f, 11f);
                rt.anchoredPosition = new Vector2(n % 2 == 0 ? -6.5f : 6.5f, n < 2 ? 6.5f : -6.5f);
                var img = go.AddComponent<Image>();
                img.sprite = src.sprite;
                img.color = src.color.a > 0.01f ? new Color(src.color.r, src.color.g, src.color.b, 1f) : Color.white;
                img.preserveAspect = true;
                img.raycastTarget = false;
                f.Minis.Add(img);
                n++;
            }
        }

        private static Image IconOf(RectTransform t)
        {
            var b = t.GetComponent<ThemedButton>();
            if (b != null && b.IconImage != null) return b.IconImage;
            var img = t.GetComponent<Image>();
            return img;
        }

        /// <summary>A readable name for a button: its tooltip if themed, else its object name.</summary>
        private string Pretty(string key)
        {
            var t = Resolve(key);
            var b = t != null ? t.GetComponent<ThemedButton>() : null;
            string tip = null;
            try { if (b != null && b.Tooltip != null) tip = b.Tooltip(); } catch (System.Exception) { }
            if (!string.IsNullOrEmpty(tip))
            {
                int cut = tip.IndexOf("  ");
                return cut > 0 ? tip.Substring(0, cut) : tip;
            }
            return key.Replace("Button ", "").Replace(" (StudioAPI)", "");
        }

        private void Open(Folder f)
        {
            Close();
            _open = f;
            if (_panel == null)
            {
                var go = new GameObject(ThemedButton.OwnPrefix + "Folder Panel", typeof(RectTransform));
                go.layer = gameObject.layer;
                go.transform.SetParent(_rt, false);
                _panel = (RectTransform)go.transform;
                _panel.anchorMin = _panel.anchorMax = new Vector2(0f, 1f);
                _panel.pivot = new Vector2(0f, 1f);
                var bg = go.AddComponent<Image>();
                bg.sprite = Sprites.Panel;
                bg.type = Image.Type.Sliced;

                // The folder's name, editable in place.
                var tgo = new GameObject(ThemedButton.OwnPrefix + "Folder Name", typeof(RectTransform));
                tgo.transform.SetParent(_panel, false);
                var trt = (RectTransform)tgo.transform;
                trt.anchorMin = new Vector2(0f, 1f); trt.anchorMax = new Vector2(1f, 1f);
                trt.pivot = new Vector2(0.5f, 1f);
                trt.offsetMin = new Vector2(PanelPad, -TitleH - 4f); trt.offsetMax = new Vector2(-PanelPad, -4f);
                var textGo = new GameObject(ThemedButton.OwnPrefix + "Text", typeof(RectTransform));
                textGo.transform.SetParent(tgo.transform, false);
                var xrt = (RectTransform)textGo.transform;
                xrt.anchorMin = Vector2.zero; xrt.anchorMax = Vector2.one; xrt.offsetMin = xrt.offsetMax = Vector2.zero;
                var text = Labels.Configure(textGo.AddComponent<Text>(), Fonts.Semibold, TextAnchor.MiddleLeft, 12, 9);
                text.color = Palette.White(0.9f);
                text.supportRichText = false;
                tgo.AddComponent<Image>().color = Color.clear;
                _title = tgo.AddComponent<InputField>();
                _title.textComponent = text;
                _title.lineType = InputField.LineType.SingleLine;
                _title.characterLimit = 24;
                _title.onEndEdit.AddListener(v =>
                {
                    if (_open == null) return;
                    v = v.Trim();
                    if (v.Length > 0) { _open.Name = v; Save(); }
                    _title.text = _open.Name;
                });
            }
            _panel.gameObject.SetActive(true);
            _title.text = f.Name;
            _panel.SetAsLastSibling();
            foreach (var m in f.Members) { var t = Resolve(m); if (t != null) t.SetAsLastSibling(); }
            LayoutPanel();
        }

        /// <summary>The open folder's panel beside the folder, its buttons in a grid inside it.</summary>
        private void LayoutPanel()
        {
            var members = _open.Members.Select(Resolve).Where(t => t != null).ToList();
            int cols = Mathf.Clamp(members.Count, 1, PanelColumns);
            int rows = Mathf.Max(1, Mathf.CeilToInt(members.Count / (float)cols));
            var size = new Vector2(PanelPad * 2f + cols * Cell - (Cell - _size.x), TitleH + 4f + PanelPad + rows * Cell - (Cell - _size.y));
            size.x = Mathf.Max(size.x, 120f);
            // To the right of the toolbar's column the folder is in, top edge level with the folder's.
            var pos = _open.Rt.anchoredPosition + new Vector2(_size.x + 10f, size.y - _size.y > 0 ? (size.y - _size.y) / 2f : 0f);
            _panel.sizeDelta = size;
            _panel.anchoredPosition = pos;
            for (int i = 0; i < members.Count; i++)
            {
                int c = i % cols, r = i / cols;
                Put(members[i], pos + new Vector2(PanelPad + c * Cell, -(TitleH + 4f) - r * Cell), true);
            }
        }

        private void Close()
        {
            if (_open == null) return;
            if (_title != null && _title.isFocused) _title.DeactivateInputField();
            _open = null;
            if (_panel != null) _panel.gameObject.SetActive(false);
            _layoutDirty = true;
        }

        // ------------------------------------------------------------------ drag and drop

        internal void BeginDrag(RectTransform t, PointerEventData e)
        {
            _dragging = t;
            t.SetAsLastSibling();
            _grab = Local(e.position) - t.anchoredPosition;
        }

        internal void Drag(RectTransform t, PointerEventData e)
        {
            if (_dragging != t) return;
            t.anchoredPosition = Local(e.position) - _grab;
            var target = TargetUnder(e.position, t);
            if (target != _hoverTarget)
            {
                if (_hoverTarget != null) _hoverTarget.localScale = Vector3.one;
                _hoverTarget = target;
                if (_hoverTarget != null) _hoverTarget.localScale = new Vector3(1.15f, 1.15f, 1f);
            }
        }

        internal void EndDrag(RectTransform t, PointerEventData e)
        {
            if (_dragging != t) return;
            if (_hoverTarget != null) _hoverTarget.localScale = Vector3.one;
            _hoverTarget = null;
            _dragging = null;
            try { Drop(t, e.position); }
            catch (System.Exception ex) { StudioThemePlugin.Log.LogWarning("Toolbar drop: " + ex.Message); }
            Save();
            _layoutDirty = true;
            Layout();
        }

        private string KeyOf(RectTransform t)
        {
            foreach (var f in _folders.Values) if (f.Rt == t) return "@" + f.Id;
            if (t.name == "Button Target") return _order.Contains("Button Axis") || FolderOf("Button Axis") != null ? "Button Axis" : t.name;
            return t.name;
        }

        /// <summary>The top-level button or folder under the pointer (not the one being dragged).</summary>
        private RectTransform TargetUnder(Vector2 screen, RectTransform dragged)
        {
            if (_open != null && PointerOver(_panel, screen) && FolderOf(KeyOf(dragged)) != _open) return _open.Rt;
            var cells = Cells();
            foreach (var key in TopLevel(cells))
            {
                var t = IsFolderKey(key) ? _folders[key.Substring(1)].Rt : Resolve(key);
                if (t == null || t == dragged) continue;
                if (PointerOver(t, screen)) return t;
            }
            return null;
        }

        private void Drop(RectTransform dragged, Vector2 screen)
        {
            var key = KeyOf(dragged);
            var from = IsFolderKey(key) ? null : FolderOf(key);
            var cells = Cells();
            var top = TopLevel(cells);
            if (_order.Count == 0) _order.AddRange(top);   // first change: freeze today's order
            var target = TargetUnder(screen, dragged);
            string targetKey = target != null ? KeyOf(target) : null;

            if (targetKey != null && IsFolderKey(targetKey) && !IsFolderKey(key))
            {
                // Onto a folder: into it.
                var f = _folders[targetKey.Substring(1)];
                if (from != f)
                {
                    RemoveEverywhere(key);
                    f.Members.Add(key);
                }
            }
            else if (targetKey != null && !IsFolderKey(targetKey) && !IsFolderKey(key))
            {
                // Onto a button: a new folder holding both, where that button was.
                var tf = FolderOf(targetKey);
                if (tf != null) { RemoveEverywhere(key); tf.Members.Add(key); }
                else
                {
                    int at = IndexIn(_order, targetKey, top);
                    RemoveEverywhere(key);
                    RemoveEverywhere(targetKey);
                    var f = new Folder { Id = NewId() };
                    f.Members.Add(targetKey);
                    f.Members.Add(key);
                    f.Name = DefaultName(f);
                    _folders[f.Id] = f;
                    _order.Insert(Mathf.Clamp(at, 0, _order.Count), "@" + f.Id);
                }
            }
            else
            {
                // An empty spot: move there (out of its folder, if it was in one).
                int at = NearestIndex(screen, cells, top);
                RemoveEverywhere(key);
                _order.Insert(Mathf.Clamp(at, 0, _order.Count), key);
                if (from != null && _open == from && from.Members.Count == 0) Close();
            }
            Tidy();
        }

        private static int IndexIn(List<string> order, string key, List<string> top)
        {
            int i = order.IndexOf(key);
            return i >= 0 ? i : order.Count;
        }

        /// <summary>Index in the order of the cell nearest the pointer.</summary>
        private int NearestIndex(Vector2 screen, List<Vector2> cells, List<string> top)
        {
            var p = Local(screen);
            int best = top.Count;
            float bestD = float.MaxValue;
            for (int i = 0; i < cells.Count && i <= top.Count; i++)
            {
                var c = cells[i] + new Vector2(_size.x / 2f, -_size.y / 2f);
                float d = (c - p).sqrMagnitude;
                if (d < bestD) { bestD = d; best = i; }
            }
            if (best >= top.Count) return _order.Count;
            int idx = _order.IndexOf(top[best]);
            return idx >= 0 ? idx : _order.Count;
        }

        private void RemoveEverywhere(string key)
        {
            _order.Remove(key);
            foreach (var f in _folders.Values) f.Members.Remove(key);
        }

        /// <summary>Folders with one button left dissolve into that button; empty ones go.</summary>
        private void Tidy()
        {
            foreach (var f in _folders.Values.ToList())
            {
                if (f.Members.Count >= 2) continue;
                int at = _order.IndexOf("@" + f.Id);
                _order.Remove("@" + f.Id);
                if (f.Members.Count == 1) _order.Insert(at >= 0 ? at : _order.Count, f.Members[0]);
                if (_open == f) Close();
                if (f.Rt != null) Destroy(f.Rt.gameObject);
                _folders.Remove(f.Id);
            }
            foreach (var f in _folders.Values) if (f.Rt != null) EnsureFolderView(f);
        }

        private string NewId()
        {
            int i = 1;
            while (_folders.ContainsKey("f" + i)) i++;
            return "f" + i;
        }

        private static string DefaultName(Folder f)
        {
            bool plugins = f.Members.All(m => m.EndsWith("(StudioAPI)"));
            bool studio = f.Members.All(m => !m.EndsWith("(StudioAPI)"));
            return plugins ? "Plugins" : studio ? "Tools" : "Folder";
        }

        // ------------------------------------------------------------------ helpers

        private Vector2 Local(Vector2 screen)
        {
            var canvas = _rt.GetComponentInParent<Canvas>();
            Camera cam = canvas != null && canvas.renderMode != RenderMode.ScreenSpaceOverlay ? canvas.worldCamera : null;
            Vector2 p;
            RectTransformUtility.ScreenPointToLocalPointInRectangle(_rt, screen, cam, out p);
            return p;
        }

        private bool PointerOver(RectTransform t) { return PointerOver(t, Input.mousePosition); }

        private bool PointerOver(RectTransform t, Vector2 screen)
        {
            if (t == null || !t.gameObject.activeInHierarchy) return false;
            var canvas = t.GetComponentInParent<Canvas>();
            Camera cam = canvas != null && canvas.renderMode != RenderMode.ScreenSpaceOverlay ? canvas.worldCamera : null;
            return RectTransformUtility.RectangleContainsScreenPoint(t, screen, cam);
        }

        public void Remove()
        {
            if (_removed) return;
            _removed = true;
            foreach (var kv in _natural)
            {
                if (kv.Key == null) continue;
                kv.Key.anchoredPosition = kv.Value;
                kv.Key.localScale = Vector3.one;
                var d = kv.Key.GetComponent<ToolbarDrag>();
                if (d != null) Destroy(d);
            }
            foreach (var f in _folders.Values) if (f.Rt != null) Destroy(f.Rt.gameObject);
            if (_panel != null) Destroy(_panel.gameObject);
            Destroy(this);
        }

        /// <summary>Drag handling on each toolbar button and folder. A drag never counts as a click.</summary>
        internal class ToolbarDrag : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
        {
            public ToolbarFolders Owner;
            public void OnBeginDrag(PointerEventData e)
            {
                if (Owner == null || e.button != PointerEventData.InputButton.Left) return;
                e.eligibleForClick = false;
                Owner.BeginDrag((RectTransform)transform, e);
            }
            public void OnDrag(PointerEventData e) { if (Owner != null) Owner.Drag((RectTransform)transform, e); }
            public void OnEndDrag(PointerEventData e) { if (Owner != null) Owner.EndDrag((RectTransform)transform, e); }
        }

        /// <summary>Tooltip for a folder: its name and what's in it.</summary>
        private class FolderTip : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
        {
            public System.Func<string> Text;
            public void OnPointerEnter(PointerEventData e) { TooltipView.Show((RectTransform)transform, Text()); }
            public void OnPointerExit(PointerEventData e) { TooltipView.Hide(transform); }
        }
    }
}
