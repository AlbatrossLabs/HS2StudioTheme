using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace HS2StudioTheme
{
    /// <summary>
    /// Grows a panel's glass downwards when its contents reach (or pass) its bottom edge, so the last
    /// row has the same breathing room as the first. Studio's old pictures had a frame that hid tight
    /// bottoms; plugins that add rows (Joint Adjustment) can also run past the end.
    /// </summary>
    internal class PanelFit : MonoBehaviour
    {
        private const float Bottom = 10f;   // space under the last row

        private RectTransform _rt;
        private Vector2 _origSize;
        private float _next;
        private bool _removed;
        private readonly List<Graphic> _graphics = new List<Graphic>();
        private readonly Vector3[] _corners = new Vector3[4];

        public static PanelFit Attach(RectTransform panel)
        {
            if (panel == null || panel.GetComponent<PanelFit>() != null) return null;
            if (panel.anchorMin != panel.anchorMax || panel.pivot.y != 1f) return null;   // only top-anchored, fixed-size panels
            var f = panel.gameObject.AddComponent<PanelFit>();
            f._rt = panel;
            f._origSize = panel.sizeDelta;
            return f;
        }

        private void OnEnable() { _next = 0f; }

        private void LateUpdate()
        {
            if (_removed || Time.unscaledTime < _next) return;
            _next = Time.unscaledTime + 0.5f;

            // Lowest visible content (the panel's own picture and the theme's captions don't count).
            float lowest = 0f;
            bool any = false;
            GetComponentsInChildren(false, _graphics);
            foreach (var g in _graphics)
            {
                if (g.transform == transform || g.name.StartsWith(ThemedButton.OwnPrefix)) continue;
                if (g.transform.parent != null && g.transform.parent.name.StartsWith(ThemedButton.OwnPrefix)) continue;
                g.rectTransform.GetWorldCorners(_corners);
                float y = _rt.InverseTransformPoint(_corners[0]).y;
                if (!any || y < lowest) { lowest = y; any = true; }
            }
            if (!any) return;

            // Local y runs from 0 at the top (pivot) downwards.
            float needed = Mathf.Max(_origSize.y, -lowest + Bottom);
            if (Mathf.Abs(_rt.sizeDelta.y - needed) > 0.5f)
                _rt.sizeDelta = new Vector2(_rt.sizeDelta.x, needed);
        }

        public void Remove()
        {
            if (_removed) return;
            _removed = true;
            if (_rt != null) _rt.sizeDelta = _origSize;
            Destroy(this);
        }
    }
}
