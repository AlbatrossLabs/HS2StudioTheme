using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;

namespace HS2StudioTheme
{
    /// <summary>
    /// The top of the screen: Studio's six show/hide switches as one capsule in the top-right corner,
    /// and the camera bar (slots plus the camera selector) as one capsule centred at the top.
    /// </summary>
    internal static class TopBar
    {
        // StudioScene.drawInfo fields, in the order of Studio's visibleFlags.
        private static readonly string[] ImageFields = { "imageMenu", "imageWork", "imageMove", "imageColor", "imageOption", "imageCamera" };
        private static readonly string[] Icons = { "v_menu", "v_work", "v_gizmo", "v_color", "v_option", "v_camera" };
        private static readonly string[] Names = { "Main menu", "Workspace", "Move gizmos", "Color picker", "Map and object controls", "Camera bar" };

        private const float ToggleW = 34f, ToggleH = 30f, Gap = 2f, Pad = 4f, Margin = 8f;

        public static void Apply(Undo undo)
        {
            var scene = Object.FindObjectOfType<StudioScene>();
            if (scene == null)
            {
                StudioThemePlugin.Log.LogWarning("Studio's top bar not found");
                return;
            }
            var draw = Traverse.Create(scene).Field("drawInfo").GetValue();
            if (draw == null) return;
            var drawT = Traverse.Create(draw);

            var toggles = new List<RectTransform>();
            for (int i = 0; i < ImageFields.Length; i++)
            {
                var image = drawT.Field(ImageFields[i]).GetValue<Image>();
                var button = image != null ? image.GetComponent<Button>() : null;
                if (button == null) continue;

                var rt = (RectTransform)button.transform;
                Place(rt, new Vector2(-(Margin + Pad) - (ImageFields.Length - 1 - i) * (ToggleW + Gap), -(Margin + Pad)),
                    new Vector2(ToggleW, ToggleH), undo);

                var themed = ThemedButton.Attach(button, ButtonKind.ViewToggle, Icons[i], null, i);
                if (themed == null) continue;
                int index = i;
                themed.Tooltip = () => Names[index] + ": " + (Shown(index) ? "shown" : "hidden");
                undo.Add(themed.Remove);
                toggles.Add(rt);
            }

            if (toggles.Count > 0)
            {
                var column = toggles[0].parent;
                if (column != null && column.GetComponent<Graphic>() == null)
                {
                    var glass = column.gameObject.AddComponent<GlassRect>();
                    glass.sprite = Sprites.Backdrop;
                    glass.around = toggles.ToArray();
                    glass.padding = Pad;
                    glass.corner = Palette.BackdropRadius;
                    glass.color = Color.white;
                    undo.Add(() => { if (glass != null) Object.DestroyImmediate(glass); });
                }
            }

            var cameraBar = drawT.Field("objCamera").GetValue<GameObject>();
            if (cameraBar != null)
            {
                var bar = CameraBar.Attach((RectTransform)cameraBar.transform, undo);
                if (bar != null) undo.Add(bar.Remove);
            }
        }

        private static bool Shown(int index)
        {
            try { return Studio.Studio.Instance.workInfo.visibleFlags[index]; }
            catch (System.Exception) { return true; }
        }

        /// <summary>Anchor to the top-right corner at this offset and size, recording the old layout.</summary>
        private static void Place(RectTransform rt, Vector2 position, Vector2 size, Undo undo)
        {
            var aMin = rt.anchorMin; var aMax = rt.anchorMax; var pivot = rt.pivot;
            var pos = rt.anchoredPosition; var sz = rt.sizeDelta;
            rt.anchorMin = rt.anchorMax = Vector2.one;
            rt.pivot = Vector2.one;
            rt.anchoredPosition = position;
            rt.sizeDelta = size;
            undo.Add(() =>
            {
                if (rt == null) return;
                rt.anchorMin = aMin; rt.anchorMax = aMax; rt.pivot = pivot;
                rt.anchoredPosition = pos; rt.sizeDelta = sz;
            });
        }
    }

    /// <summary>
    /// Keeps the camera bar centred at the top of the screen and drawn as one glass capsule. Works on
    /// Studio's ten slots or on MoarCamz's scrolling slot strip with its extra buttons, and re-measures
    /// twice a second so slots added later are themed and the bar stays centred.
    /// </summary>
    internal class CameraBar : MonoBehaviour
    {
        private const string Selector = "Image Camera Setting";

        private RectTransform _rt;
        private Vector2 _origPos;
        private GlassRect _glass;
        private readonly List<RectTransform> _items = new List<RectTransform>();
        private readonly List<ThemedButton> _buttons = new List<ThemedButton>();
        private readonly Undo _undo = new Undo();
        private float _next;
        private bool _removed;

        public static CameraBar Attach(RectTransform bar, Undo undo)
        {
            if (bar == null || bar.GetComponent<CameraBar>() != null) return null;
            var c = bar.gameObject.AddComponent<CameraBar>();
            c.Init(bar);
            return c;
        }

        private void Init(RectTransform bar)
        {
            _rt = bar;
            _origPos = bar.anchoredPosition;

            if (GetComponent<Graphic>() == null)
            {
                _glass = gameObject.AddComponent<GlassRect>();
                _glass.sprite = Sprites.Backdrop;
                _glass.padding = 6f;
                _glass.corner = Palette.PanelRadius;
                _glass.color = Color.white;
            }

            StyleSelector();
            Scan();
            Centre();
        }

        /// <summary>The camera selector: transparent box (the capsule is behind it), small title, themed dropdown.</summary>
        private void StyleSelector()
        {
            var selector = transform.Find(Selector);
            if (selector == null) return;
            var box = selector.GetComponent<Image>();
            if (box != null) ControlStyler.Swap(box, box.sprite, box.type, Palette.White(0f), _undo);
            var title = selector.Find("TextMeshPro Title");
            var titleText = title != null ? title.GetComponent<TMPro.TMP_Text>() : null;
            if (titleText != null)
            {
                var label = ThemedLabel.Attach(titleText, false, 11, 0.6f);
                if (label != null) _undo.Add(label.Remove);
            }
            var dropdown = selector.GetComponentInChildren<TMPro.TMP_Dropdown>(true);
            if (dropdown != null) ControlStyler.StyleTmpDropdown(dropdown, _undo);
        }

        private void LateUpdate()
        {
            if (_removed) return;
            if (Time.unscaledTime >= _next)
            {
                _next = Time.unscaledTime + 0.5f;
                Scan();
            }
            Centre();
        }

        /// <summary>Theme new slots and work out which rects make up the bar.</summary>
        private void Scan()
        {
            _items.Clear();

            foreach (var button in GetComponentsInChildren<Button>(true))
            {
                if (button.name != "Button Load" && button.name != "Button Save") continue;
                int n;
                if (button.transform.parent == null || !int.TryParse(button.transform.parent.name, out n)) continue;

                bool load = button.name == "Button Load";
                var themed = ThemedButton.Attach(button, load ? ButtonKind.Slot : ButtonKind.Tab, null, null);
                if (themed == null) continue;
                if (!load)
                {
                    var slot = button.transform.parent;
                    themed.Tooltip = () => "Save view to " + (int.Parse(slot.name) + 1);
                }
                if (!_buttons.Contains(themed)) _buttons.Add(themed);
            }

            // MoarCamz's scrolling strip, or Studio's own slots.
            var scroll = GetComponentInChildren<ScrollRect>();
            if (scroll != null && scroll.isActiveAndEnabled)
                _items.Add(scroll.viewport != null ? scroll.viewport : (RectTransform)scroll.transform);
            else
                foreach (var b in _buttons)
                    if (b != null && b.isActiveAndEnabled) _items.Add((RectTransform)b.transform);

            var selector = transform.Find(Selector) as RectTransform;
            if (selector != null && selector.gameObject.activeInHierarchy) _items.Add(selector);

            // Anything else on the top row (MoarCamz's add / remove / centre buttons).
            for (int i = 0; i < transform.childCount; i++)
            {
                var child = transform.GetChild(i);
                int n;
                if (!child.gameObject.activeInHierarchy || child == selector || int.TryParse(child.name, out n)) continue;
                if (scroll != null && (child == scroll.transform || scroll.transform.IsChildOf(child))) continue;
                foreach (var b in child.GetComponentsInChildren<Button>())
                {
                    var brt = (RectTransform)b.transform;
                    if (OnTopRow(brt)) _items.Add(brt);
                }
            }

            if (_glass != null) _glass.around = _items.ToArray();
        }

        private readonly Vector3[] _corners = new Vector3[4];

        private bool OnTopRow(RectTransform rt)
        {
            rt.GetWorldCorners(_corners);
            float top = _rt.InverseTransformPoint(_corners[1]).y;
            return top > -40f;   // the slot row sits 8 units below the top; MoarCamz's settings panel is far lower
        }

        /// <summary>Move the bar so its contents are centred on the screen's top middle.</summary>
        private void Centre()
        {
            bool any = false;
            float min = 0f, max = 0f;
            foreach (var rt in _items)
            {
                if (rt == null || !rt.gameObject.activeInHierarchy) continue;
                rt.GetWorldCorners(_corners);
                for (int i = 0; i < 4; i++)
                {
                    float x = _rt.InverseTransformPoint(_corners[i]).x;
                    if (!any) { min = max = x; any = true; }
                    else { min = Mathf.Min(min, x); max = Mathf.Max(max, x); }
                }
            }
            if (!any) return;

            // Child positions are relative to the bar, so this offset doesn't depend on where the bar is now.
            var target = new Vector2(-(min + max) / 2f, _origPos.y);
            if ((_rt.anchoredPosition - target).sqrMagnitude > 0.25f) _rt.anchoredPosition = target;
        }

        public void Remove()
        {
            if (_removed) return;
            _removed = true;
            foreach (var b in _buttons) if (b != null) b.Remove();
            _buttons.Clear();
            _undo.Run();
            if (_glass != null) DestroyImmediate(_glass);
            if (_rt != null) _rt.anchoredPosition = _origPos;
            Destroy(this);
        }
    }
}
